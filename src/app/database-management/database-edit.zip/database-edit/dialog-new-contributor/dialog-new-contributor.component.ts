import { Component, OnInit } from '@angular/core';
import {PermissionType} from '../../Permission';

export interface DialogNewContributorResult {
  login: string;
  sqllogin: string;
}

@Component({
  selector: 'app-dialog-new-contributor',
  templateUrl: './dialog-new-contributor.component.html',
  styleUrls: ['./dialog-new-contributor.component.scss']
})
export class DialogNewContributorComponent implements OnInit {

  permissionSelected: PermissionType = null;
  loginSelected: string;

  constructor() { }

  ngOnInit(): void {
  }

  isFormValid(): boolean {
    return false;
  }

  submit(): DialogNewContributorResult {
    return {login: 'test', sqllogin: 'sqltest'};
  }

  selectPermission(selected: PermissionType): void {
    this.permissionSelected = selected;
  }

  onLoginSelect(selected: string): void {
    this.loginSelected = selected;
  }
}
