import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-other-contributor-form',
  templateUrl: './other-contributor-form.component.html',
  styleUrls: ['./other-contributor-form.component.scss']
})
export class OtherContributorFormComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
